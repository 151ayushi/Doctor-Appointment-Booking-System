
export class Schedule {
  doctorScheduleId: number;
  startTime: String;
  endTime: String;
  

}
