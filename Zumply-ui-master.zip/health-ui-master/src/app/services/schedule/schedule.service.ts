import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Schedule } from './schedule';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ScheduleService {
  private baseURL = "http://localhost:8080"

  constructor(private httpClient: HttpClient) { }

  getScheduleList(doctorId: number): Observable<Schedule[]> {
    let token = localStorage.getItem('token');
    console.log(token);
    const headers = new HttpHeaders({

      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`
  
    });
    const requestOptions = { headers: headers }; 
    return this.httpClient.get<Schedule[]>(`${this.baseURL}/api/v1/doctorId/${doctorId}`,requestOptions);
    
  }
}
