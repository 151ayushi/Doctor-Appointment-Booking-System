export class ManageDoctor {
    id: number;
    fullName: string;
    gender: string;
    mobile: bigint;
    email: string;
    registrationNumber: string;
    rating: number;
    doctorSpecialization: any;
    hospital: any;
    fees: bigint;
}
