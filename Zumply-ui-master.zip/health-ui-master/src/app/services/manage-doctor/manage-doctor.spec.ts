import { ManageDoctor } from './manage-doctor';

describe('ManageDoctor', () => {
  it('should create an instance', () => {
    expect(new ManageDoctor()).toBeTruthy();
  });
});
