export class User {
    email:string;
    password:string;
    username:string;
    firstName:string;
    middleName:string;
    lastName:string;
    mobile:string;
    gender:string;
}
