export class Hospital {
    hospitalId: number;
    name: string;
    address: string;
}
