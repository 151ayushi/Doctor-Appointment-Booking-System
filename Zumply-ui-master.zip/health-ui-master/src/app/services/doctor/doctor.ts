export class Doctor {
    id:number;
    fullName: String;
    name=String;
    hospital: String;
    rating: String;
    registrationNumber: number;
    doctorId: number;
    doctorName: String;
    startDate: Date;
    endDate: Date;
    fees: number;
    
}

