export class Category {
        specializationName:string;
        id:number;
}
