import { Orderlist } from './orderlist';

describe('User', () => {
  it('should create an instance', () => {
    expect(new Orderlist()).toBeTruthy();
  });
});
