export class Orderlist{
    AppointmentId:number;
    DoctorName:string;
    Amount:number;
    StartTime:Date;
    EndTime:Date;
    appointmentstatus:string;
    status:string;
    Reshedule: string;
    Cancellation:string;
    lastModifiedDate:string;
    Appointment:string;

}
