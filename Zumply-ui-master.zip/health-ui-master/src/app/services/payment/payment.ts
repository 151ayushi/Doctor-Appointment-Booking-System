export class Payment {
    amount: number;
    currency = 'INR';
    status: string;
    createdAt: Date;
}
