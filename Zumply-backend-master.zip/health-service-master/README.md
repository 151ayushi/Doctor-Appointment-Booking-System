$# health-service
Backend code for health-service

#DO NOT MERGE DIRECTLY INTO MASTER OR 
#DO NOT WORK ON MASTER BRANCH
#RATHER CREATE YOUR OWN BRANCH USING Git bash.
example feature branch name: [zumply-id]/feature/task-number

