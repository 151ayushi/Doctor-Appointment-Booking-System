package com.zumply.healthservice.controller;

import com.zumply.healthservice.repository.PaymentRepository;
import com.zumply.healthservice.entity.Payment;
import com.razorpay.Order;
import com.razorpay.RazorpayClient;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@Controller
public class PaymentController {

    @Autowired
    private PaymentRepository paymentRepository;

    @RequestMapping("/payment/{id}")
    @ResponseBody
    public Payment payment(@PathVariable("id") Long Id) {
        System.out.println(Id);
        Payment paymentEntity = this.paymentRepository.findById(Id).get();
        System.out.println(paymentEntity);
        return paymentEntity;
    }

    @RequestMapping("/payment")
    @ResponseBody
    public Payment processPayment(@RequestParam Map<String, Object> data) throws Exception {
        System.out.println(data);
        Object amountObj = data.get("amount");
        if (amountObj == null) {
            throw new Exception("Amount is mandatory");
        }
        float amt = Float.parseFloat(amountObj.toString());
        Order order = null;
        try {
            RazorpayClient rj = new RazorpayClient("rzp_test_QvfhRP9slPcend", "mhCcqqxaDZ3wP3CKzBCC5XuB");

            JSONObject orderRequest = new JSONObject();
            orderRequest.put("amount", (int)(amt * 100)); // amount in the smallest currency unit
            orderRequest.put("currency","INR");
            //orderRequest.put("AppointmentId", "order_appointmentId_11");

            //creating new PaymentEntity
            order = rj.orders.create(orderRequest);
            System.out.println(order);

            //save payments in database
            Payment paymentEntity = new Payment();

            paymentEntity.setOrderId(order.get("id") != null ? order.get("id").toString() : null);
//          paymentEntity.setReferenceId(order.get("referenceId") != null ? order.get("referenceId").toString() : null);
            //paymentEntity.setPaymentId(order.get("paymentId")!= null ? order.get("paymentId").toString() : null);
            paymentEntity.setAmount(order.get("amount") != null ? Float.parseFloat(order.get("amount").toString())/100 : null);
            paymentEntity.setCurrency(order.get("currency") != null ? order.get("currency").toString() : null);
            paymentEntity.setMode(order.get("method") != null ? order.get("method").toString() : null);
           // paymentEntity.setAppointmentId(order.get("AppointmentId") != null ? order.get("AppointmentId").toString() : null);
            paymentEntity.setStatus(order.get("status") != null ? order.get("status").toString() : null);
           // paymentEntity.setCreated_at(order.get("created_at")!= null ? order.get("created_at").toString() : null);

            Payment savepay= this.paymentRepository.save(paymentEntity);
            return savepay;

        } catch (Exception e) {
            System.out.println("Order generation error: " + e.getMessage());
            throw e;
        }

    }
    @PostMapping("/payment/success/{id}")
    @ResponseBody
    public Payment success(@PathVariable("id") Long Id) {
        System.out.println(Id);
        Payment paymentEntity = this.paymentRepository.findById(Id).get();

        paymentEntity.setStatus("paid");
        Payment savepay = this.paymentRepository.save(paymentEntity);
        System.out.println(savepay);

        return savepay;
    }

    @PostMapping("/payment/fail/{id}")
    @ResponseBody
    public Payment fail(@PathVariable("id") Long Id) {
        System.out.println(Id);
        Payment paymentEntity = this.paymentRepository.findById(Id).get();

        paymentEntity.setStatus("failed");
        Payment savepay = this.paymentRepository.save(paymentEntity);
        System.out.println(savepay);

        return savepay;
    }

}