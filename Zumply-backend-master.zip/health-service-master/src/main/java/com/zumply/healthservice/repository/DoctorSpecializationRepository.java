package com.zumply.healthservice.repository;


import com.zumply.healthservice.entity.DoctorSpecialization;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface DoctorSpecializationRepository extends JpaRepository<DoctorSpecialization, Integer> {
    Optional<DoctorSpecialization> findBySpecializationName(String specializationName);

    Page<DoctorSpecialization> findAll(Pageable pageable);
}
